package com.devsuperior.uri2611.projections;

public interface MovieMinProjection {

	Long getId();
	String getName();
}
