package com.devsuperior.uri2621;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uri2621ApplicationTests {

	@Test
	void contextLoads() {
	}

}
