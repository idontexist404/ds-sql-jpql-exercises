package com.devsuperior.uri2609;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Uri2609ApplicationTests {

	@Test
	void contextLoads() {
	}

}
